<?
include_once ("configuracao.php");
require_once('smarty/libs/Smarty.class.php');
$smarty = new Smarty();

$smarty->template_dir = "templates/";
$smarty->compile_dir = "templates_c/";

//criar o link com o MySQL
$link = mysql_connect ("localhost","root","");

//Informar qual � o banco de dados que ser� utilizado
$db_selected = mysql_select_db('biblioteca', $link);
if (!$db_selected) {
	die ('N�o foi poss�vel selecionar o banco biblioteca : ' . mysql_error());
}

//Primeira consulta = �ltimos lan�amentos
$resultado1 = mysql_query ("SELECT l.id, l.nome FROM livro l order by l.data_publicacao desc limit 5");


while ($linha = mysql_fetch_assoc($resultado1))
{ 
	$listaLivros[] = $linha;
}

$smarty->assign('listaLivros',$listaLivros);
$smarty->assign('tituloPagina',"Index | ".$tituloSite);
$smarty->assign('ondeEstou','index');
$smarty->assign('descricaoPagina','este pasdjfklasjfkajf kajfkjakf');

//$smarty->compile_check = false;		

$smarty->display('index.tpl');
?>