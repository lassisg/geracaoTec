<?
require_once('smarty/libs/Smarty.class.php');
$smarty = new Smarty();

$smarty->template_dir = "templates/";
$smarty->compile_dir = "templates_c/";

$smarty->assign('name','PHP ���');

$smarty->display('testesmarty.tpl');
?>